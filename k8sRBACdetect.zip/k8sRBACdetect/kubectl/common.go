package kubectl

import (
	"bytes"
	"crypto/tls"
	"io/ioutil"
	"k8sRBACdetect/conf"
	"net/http"
	"strings"
)

type K8sRequestOption struct {
	cert     string
	key      string
	Server   string
	Api      string
	Method   string
	PostData string
}

func ApiRequest(opts K8sRequestOption) (string, error) {
	if opts.cert == "" {
		opts.cert = conf.AdminCert
	}
	if opts.key == "" {
		opts.key = conf.AdminCertKey
	}
	if opts.Server == "" {
		opts.Server = conf.ApiServer
	}
	opts.Method = strings.ToUpper(opts.Method)

	cert, err := tls.LoadX509KeyPair(opts.cert, opts.key)
	if err != nil {
		return "", err
	}
	client := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true, Certificates: []tls.Certificate{cert}},
		},
	}

	url := "https://" + opts.Server + opts.Api
	request, err := http.NewRequest(opts.Method, url, bytes.NewBuffer([]byte(opts.PostData)))
	if err != nil {
		return "", err
	}

	resp, err := client.Do(request)
	if err != nil {
		return "", err
	}

	content, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	res := string(content)
	return res, nil
}
