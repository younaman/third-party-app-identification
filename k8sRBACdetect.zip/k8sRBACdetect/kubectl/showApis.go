package kubectl

func showPodsAndRules() {

}
