package conf

var AdminCert = "/Users/click/.kube/client.pem"
var AdminCertKey = "/Users/click/.kube/client-key.pem"
var ApiServer = "cls-diq60suu.ccs.tencent-cloud.com"
var BypassAuthRes = map[string][]string{
	// bypass authorization
	"roles":           {"escalate", "bind"},
	"clusterroles":    {"escalate", "bind"},
	"users":           {"impersonate"},
	"groups":          {"impersonate"},
	"serviceaccounts": {"impersonate"},
}
var GetTokenRes = map[string][]string{
	// get token
	"secrets":                             {"list", "get", "create"},
	"certificatesigningrequests":          {"create"},
	"certificatesigningrequests/approval": {"update"},
}
var RceAndGetTokenRes = map[string][]string{
	// rce and get its token
	"serviceaccounts/token": {"create"},
	"pods":                  {"create", "patch", "update"},
	"daemonsets":            {"create", "patch", "update"},
	"deoloyments":           {"create", "patch", "update"},
	"replicasets":           {"create", "patch", "update"},
	"statefulsets":          {"create", "patch", "update"},
	"cronjobs":              {"craete", "patch", "update"},
	"jobs":                  {"create", "patch", "update"},
	"pods/exec":             {"create"},
	"nodes/proxy":           {"create"},
}
var ControlSchedRes = map[string][]string{
	// Control scheduling
	"pods":          {"delete"},
	"pods/eviction": {"create"},
	"daemonsets":    {"create", "patch", "update"},
	"nodes":         {"delete", "patch", "update"},
	"nodes/status":  {"patch", "update"},
}
var MitM = map[string][]string{
	"services/status": {"patch"},
}
